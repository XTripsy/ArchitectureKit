using Namespace_Level_Event;

namespace Namespace_InputMainMenu_Event
{
    internal readonly struct ActionPlayMainMenuState : IEvent { }
}

namespace Namespace_InputMainMenu
{

    internal sealed class InputActionMainMenuState
    {
        IEventBus _bus;

        public InputActionMainMenuState(IEventBus bus)
        {
            _bus = bus;
        }

        public void PlayMainMenu()
        {
            _bus.IPublish(new LevelRequest("lobby_scene"));
            _bus.IPublish(new RequestStateEnter("lobby_state"));
        }
    }
}
