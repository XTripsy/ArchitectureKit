﻿namespace Namespace_Object
{
    internal class ObjectManager : IObjectManager
    {

    }
}
