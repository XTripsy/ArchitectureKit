﻿namespace Namespace_Object
{
    [System.Serializable]
    internal struct ObjectGroup
    {

    }

    internal sealed class ObjectInstaller : IObjectInstaller
    {
        public void Install(IBootstrapContext installer)
        {

        }
    }
}
