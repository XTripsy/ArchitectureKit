﻿public interface ITriggerSystem
{

}