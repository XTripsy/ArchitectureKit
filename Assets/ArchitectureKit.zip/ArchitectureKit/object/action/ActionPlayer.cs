﻿using Namespace_ActionSpawnPlayer_Event;
using Namespace_ExitLobby_Event;
using UnityEngine;

namespace Namespace_ActionSpawnPlayer_Event
{
    internal readonly struct ActionSpawnPlayer : IEvent { }
    internal readonly struct ActionDeSpawnPlayer : IEvent { }
}

namespace Namespace_ActionSpawnPlayer
{
    internal sealed class ActionPlayer
    {
        private IEventBus _bus;
        private IGameLoopManager _gameLoopManager;
        private IObjectManager _objectManager;

        public ActionPlayer(IEventBus bus, IGameLoopManager gameLoopManager, IObjectManager objectManager)
        {
            _bus = bus;
            _gameLoopManager = gameLoopManager;
            _objectManager = objectManager;

            _bus.ISubscribe<ActionSpawnPlayer>(_ => _SpawnPlayer());
            _bus.ISubscribe<ExitLobbyPlayer>(_ => _DeSpawnPlayer());
            //_bus.ISubscribe<ActionDeSpawnPlayer>(_ => _DeSpawnPlayer());
        }

        private void _SpawnPlayer()
        {
            //_objectManager.IActive("player");
            _gameLoopManager.IActivate("player_state_manager");
        }

        private void _DeSpawnPlayer()
        {
            /*_objectManager.IDeActive("player");
            _objectManager.IGet("player").transform.position = Vector3.zero;*/
            _gameLoopManager.IDeActivate("player_state_manager");
        }
    }
}
