﻿using UnityEngine.InputSystem;
using Namespace_InputMainMenu;
using Namespace_InputMainMenu_Event;
using Namespace_UIMainMenu;
using Namespace_StateMainMenu_Event;
using Namespace_Input;

namespace Namespace_StateMainMenu
{
    internal sealed class MainMenuStateInstaller : IInstaller<IBootstrapContext>
    {
        public void Install(IBootstrapContext installer)
        {
            string name_state = "mainmenu_state";
            string name_mapping = "mainmenu_mapping";

            IEventBus bus = installer.IGetBus;
            IStateRegistry state = installer.IGetStateRegistry;
            IInputManager input = installer.IResolve<IInputManager>();
            IUIManager ui = installer.IResolve<IUIManager>();
            IGameLoopManager gameLoopManager = installer.IResolve<IGameLoopManager>();

            state.IRegister(name_state, new MainMenuState(bus));

            _InstallInput(installer, bus, input, name_mapping);
            _InstallInputAction(bus);
            _InstallUI(bus, ui);
        }

        private void _InstallInput(IBootstrapContext installer, IEventBus bus, IInputManager input, string name_mapping)
        {
            InputGroup group = installer.IGetGroup<InputGroup>();
            int index = input.IGetIndexCatalogInputAction(name_mapping, group.catalog);
            InputActionMap inputAction = group.action.FindActionMap(name_mapping, throwIfNotFound: false);
            InputCatalog.Mapping mapping = group.catalog.InputAction[index];
            IAction action = new ActionMainMenuState(bus, inputAction, mapping);
            input.IRegisterActionInput(name_mapping, action);

            bus.ISubscribe<MainMenuStateEnter>(_ => input.IActiveActionInput(name_mapping));
        }

        private void _InstallInputAction(IEventBus bus)
        {
            InputActionMainMenuState temp_input = new InputActionMainMenuState(bus);
            bus.ISubscribe<ActionPlayMainMenuState>(_ => temp_input.PlayMainMenu());
        }

        private void _InstallUI(IEventBus bus, IUIManager ui)
        {
            UIActionMainMenuState temp_ui = new UIActionMainMenuState(bus, ui);
            bus.ISubscribe<MainMenuStateEnter>(_ => temp_ui.OnMainMenuEnter());
            bus.ISubscribe<MainMenuStateExit>(_ => temp_ui.OnMainMenuExit());
        }
    }
}