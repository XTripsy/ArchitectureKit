﻿using Namespace_InputLobby_Event;
using Namespace_PlayerController;
using Namespace_PlayerModulMovement;
using Namespace_PlayerService;
using Namespace_StatePause_Event;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Namespace_PlayerState
{
    internal class PlayerStateInstaller : IInstaller<IBootstrapContext>
    {
        public void Install(IBootstrapContext installer)
        {
            IEventBus bus = installer.IGetBus;
            IGameLoopManager gameLoopManager = installer.IResolve<IGameLoopManager>();
            IObjectManager objectManager = installer.IResolve<IObjectManager>();

            IPlayerIdService playerIdService = new PlayerIdService();
            IPlayerSpawnService playerSpawnService = new PlayerSpawnerService(bus, playerIdService, objectManager, gameLoopManager);

            bus.ISubscribe<ActionJoinLobbyState>(_ => playerSpawnService.ISpawnPlayer());

            /*IUpdateManager player_state = new PlayerStateManager();
            gameLoopManager.IRegister("player_state_manager", player_state);*/

            /*_InstallEvent(bus, gameLoopManager);
            bus.ISubscribe<ActionJoinLobbyState>(_ => _InstallPlayerState(bus, objectManager, gameLoopManager));*/
        }

        private void _InstallEvent(IEventBus bus, IGameLoopManager gameLoopManager)
        {
            //bus.ISubscribe<ActionJoinLobbyState>(_ => gameLoopManager.IActivate("player_state_manager"));
            bus.ISubscribe<PauseStateExit>(_ => gameLoopManager.IActivate("player_state_manager"));
            bus.ISubscribe<PauseStateEnter>(_ => gameLoopManager.IDeActivate("player_state_manager"));
            //bus.ISubscribe<ExitLobbyPlayer>(_ => gameLoopManager.IDeActivate("player_state_manager"));
        }

        private void _InstallPlayerState(IEventBus bus, IObjectManager objectManager, IGameLoopManager gameLoopManager)
        {
            IUpdateManager stateManager = new PlayerStateManager();
            gameLoopManager.IRegister("player_state_manager", stateManager);

            var obj = objectManager.IGet("player").transform;
            PlayerModulMovement modulMovement = new PlayerModulMovement(obj.GetComponent<CharacterController>());

            IPlayerState idle_state = new PlayerStateIdle(modulMovement);
            IPlayerState move_state = new PlayerStateMovement(bus, modulMovement);

            IPlayerStateMachine player_state = new PlayerStateMachine();
            player_state.IRegister("idle", idle_state);
            player_state.IRegister("movement", move_state);

            _InstallPlayerStateMachine(stateManager as IPlayerStateManager, "player_state", player_state);

            player_state.IChangeState("idle");
            _InstallPlayerController(0, bus, player_state, obj);
        }

        private void _InstallPlayerController(int id, IEventBus bus, IPlayerStateMachine player_state, Transform obj)
        {
            var playerInput = obj.GetComponent<PlayerInput>();
            var player_controller = new PlayerController(id, playerInput, bus, player_state);
        }

        private void _InstallPlayerStateMachine(IPlayerStateManager stateManager, string name, IPlayerStateMachine playerState)
        {
            stateManager.IAddStateMachine(name, playerState);
        }
    }
}
