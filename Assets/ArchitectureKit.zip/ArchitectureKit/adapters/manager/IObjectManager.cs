﻿public interface IObjectManager
{

}